package tests

import (
	"fmt"
	"strings"
	"testing"

	vukem "github.com/AlexGalhardo/vukem"
	"github.com/AlexGalhardo/vukem/queue"
	"github.com/AlexGalhardo/vukem/vukemtest"
)

// The reset form answers alike for known and unknown emails, and the
// reset mail goes through the queue instead of being sent during the
// request, so neither the answer nor its timing reveals who has an account.
func TestPasswordResetAnswersAlike(t *testing.T) {
	t.Parallel()

	fake := queue.NewFake()
	app := authTestApp(t, vukemtest.Options{
		AppOptions: []vukem.Option{vukem.WithQueueDriver(fake)},
	})
	register(t, app, app.Client(t).Inertia(""), "dee@example.com")

	mailJobs := func() int {
		n := 0

		for _, m := range fake.Messages() {
			if m.Kind == vukem.MailJobKind {
				n++
			}
		}

		return n
	}

	// Registering queued the verification mail.
	queuedBefore := mailJobs()
	sentBefore := len(app.Mails().SentTo("dee@example.com"))

	var flashes []string

	for _, tc := range []struct {
		email string
		jobs  int
	}{
		{"nobody@example.com", 0},
		{"dee@example.com", 1},
	} {
		c := app.Client(t).Inertia("")
		c.PostJSON("/forgot-password", map[string]any{"email": tc.email}).AssertRedirect("/forgot-password")

		page := c.Get("/forgot-password").AssertInertia("Auth/ForgotPassword").Page()
		flashes = append(flashes, fmt.Sprint(page["flash"]))

		if got := mailJobs() - queuedBefore; got != tc.jobs {
			t.Errorf("after %s: %d queued reset mails, want %d", tc.email, got, tc.jobs)
		}
	}

	if flashes[0] != flashes[1] || !strings.Contains(flashes[0], "If that email has an account") {
		t.Errorf("flash for unknown / known email = %q / %q, want the same notice", flashes[0], flashes[1])
	}

	if len(app.Mails().SentTo("dee@example.com")) != sentBefore {
		t.Error("the reset mail was sent during the request instead of queued")
	}
}
