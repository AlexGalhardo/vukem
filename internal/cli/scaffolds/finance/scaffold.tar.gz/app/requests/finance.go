package requests

import "github.com/AlexGalhardo/vukem/z"

// The finance forms. Ids and amounts arrive as text (select values, "12.50")
// and are parsed by the finance service, which owns the money rules.

// Transaction is the input of the new transaction form.
type Transaction struct {
	AccountID   string `json:"accountId"   form:"accountId"`
	CategoryID  string `json:"categoryId"  form:"categoryId"`
	Kind        string `json:"kind"        form:"kind"`
	Amount      string `json:"amount"      form:"amount"`
	Description string `json:"description" form:"description"`
	Date        string `json:"date"        form:"date"`
	// Tags are tag names, created when new. Absent leaves the tags of an
	// edited transaction alone; a list, even an empty one, replaces them.
	Tags []string `json:"tags" form:"tags"`
}

// TransactionSchema validates Transaction.
var TransactionSchema = z.Struct[Transaction](z.Shape{
	"accountId":   z.String().Trim().Min(1).Max(20),
	"categoryId":  z.String().Trim().Max(20).Optional(),
	"kind":        z.String().Trim().Min(1).Max(20),
	"amount":      z.String().Trim().Min(1).Max(30),
	"description": z.String().Trim().Max(200).Optional(),
	"date":        z.String().Trim().Min(10).Max(10),
	"tags":        z.Slice(z.String().Trim().Max(120)).Max(40).Optional(),
})

// Account is the input of the new account form.
type Account struct {
	Name    string `json:"name"    form:"name"`
	Kind    string `json:"kind"    form:"kind"`
	Opening string `json:"opening" form:"opening"`
}

// AccountSchema validates Account.
var AccountSchema = z.Struct[Account](z.Shape{
	"name":    z.String().Trim().Min(1).Max(80),
	"kind":    z.String().Trim().Min(1).Max(20),
	"opening": z.String().Trim().Max(30).Optional(),
})

// Category is the input of the new category form.
type Category struct {
	Name string `json:"name" form:"name"`
	// Kind is needed for a top-level category and ignored on an edit: a
	// category never changes kind, and a subcategory takes its parent's.
	Kind     string `json:"kind"     form:"kind"`
	ParentID string `json:"parentId" form:"parentId"`
	Color    string `json:"color"    form:"color"`
	Icon     string `json:"icon"     form:"icon"`
}

// CategorySchema validates Category.
var CategorySchema = z.Struct[Category](z.Shape{
	"name":     z.String().Trim().Min(1).Max(60),
	"kind":     z.String().Trim().Max(20).Optional(),
	"parentId": z.String().Trim().Max(20).Optional(),
	"color":    z.String().Trim().Max(20).Optional(),
	"icon":     z.String().Trim().Max(20).Optional(),
})

// CategoryDelete is the input of the delete category form.
type CategoryDelete struct {
	ReassignTo string `json:"reassignTo" form:"reassignTo"`
}

// CategoryDeleteSchema validates CategoryDelete.
var CategoryDeleteSchema = z.Struct[CategoryDelete](z.Shape{
	"reassignTo": z.String().Trim().Max(20).Optional(),
})

// Tag is the input of the tag form.
type Tag struct {
	Name  string `json:"name"  form:"name"`
	Color string `json:"color" form:"color"`
}

// TagSchema validates Tag.
var TagSchema = z.Struct[Tag](z.Shape{
	"name":  z.String().Trim().Min(1).Max(120),
	"color": z.String().Trim().Max(20).Optional(),
})

// Budget is the input of the budget form.
type Budget struct {
	// CategoryID is empty for the overall budget of the workspace.
	CategoryID string `json:"categoryId" form:"categoryId"`
	Limit      string `json:"limit"      form:"limit"`
	Rollover   bool   `json:"rollover"   form:"rollover"`
}

// BudgetSchema validates Budget.
var BudgetSchema = z.Struct[Budget](z.Shape{
	"categoryId": z.String().Trim().Max(20).Optional(),
	"limit":      z.String().Trim().Min(1).Max(30),
	"rollover":   z.Bool().Optional(),
})

// Goal is the input of the goal form.
type Goal struct {
	Name       string `json:"name"       form:"name"`
	Target     string `json:"target"     form:"target"`
	TargetDate string `json:"targetDate" form:"targetDate"`
}

// GoalSchema validates Goal.
var GoalSchema = z.Struct[Goal](z.Shape{
	"name":       z.String().Trim().Min(1).Max(120),
	"target":     z.String().Trim().Min(1).Max(30),
	"targetDate": z.String().Trim().Max(10).Optional(),
})

// Contribution is the input of the goal contribution form.
type Contribution struct {
	Amount string `json:"amount" form:"amount"`
	Date   string `json:"date"   form:"date"`
	Note   string `json:"note"   form:"note"`
}

// ContributionSchema validates Contribution.
var ContributionSchema = z.Struct[Contribution](z.Shape{
	"amount": z.String().Trim().Min(1).Max(30),
	"date":   z.String().Trim().Max(10).Optional(),
	"note":   z.String().Trim().Max(200).Optional(),
})

// NotificationPreferences is the input of the preferences form: the kinds the
// person wants in the app and by mail. A kind in neither list is off.
type NotificationPreferences struct {
	InApp []string `json:"inApp" form:"inApp"`
	Email []string `json:"email" form:"email"`
}

// NotificationPreferencesSchema validates NotificationPreferences.
var NotificationPreferencesSchema = z.Struct[NotificationPreferences](z.Shape{
	"inApp": z.Slice(z.String().Trim().Max(40)).Max(20).Optional(),
	"email": z.Slice(z.String().Trim().Max(40)).Max(20).Optional(),
})

// Invite is the input of the invite form.
type Invite struct {
	Email string `json:"email" form:"email"`
	Role  string `json:"role"  form:"role"`
}

// InviteSchema validates Invite.
var InviteSchema = z.Struct[Invite](z.Shape{
	"email": z.String().Trim().Min(3).Max(254),
	"role":  z.String().Trim().Min(1).Max(20),
})

// Workspace is the input of the workspace settings form.
type Workspace struct {
	Name     string `json:"name"     form:"name"`
	Currency string `json:"currency" form:"currency"`
	// Timezone is an IANA name; empty keeps the current one.
	Timezone string `json:"timezone" form:"timezone"`
}

// WorkspaceSchema validates Workspace.
var WorkspaceSchema = z.Struct[Workspace](z.Shape{
	"name":     z.String().Trim().Min(1).Max(80),
	"currency": z.String().Trim().Min(3).Max(3),
	"timezone": z.String().Trim().Max(64).Optional(),
})

// ImportMapping is the input of the column mapping step of a CSV import.
type ImportMapping struct {
	Date        string `json:"date"        form:"date"`
	Description string `json:"description" form:"description"`
	Amount      string `json:"amount"      form:"amount"`
	Category    string `json:"category"    form:"category"`
	DateFormat  string `json:"dateFormat"  form:"dateFormat"`
	Invert      string `json:"invert"      form:"invert"`
	// AllowDuplicates is "true" to import the rows an earlier import brought in.
	AllowDuplicates string `json:"allowDuplicates" form:"allowDuplicates"`
}

// ImportMappingSchema validates ImportMapping.
var ImportMappingSchema = z.Struct[ImportMapping](z.Shape{
	// The columns are needed for a CSV (the service checks) and unused for OFX.
	"date":            z.String().Trim().Max(120).Optional(),
	"description":     z.String().Trim().Max(120).Optional(),
	"amount":          z.String().Trim().Max(120).Optional(),
	"category":        z.String().Trim().Max(120).Optional(),
	"dateFormat":      z.String().Trim().Max(20).Optional(),
	"invert":          z.String().Trim().Max(5).Optional(),
	"allowDuplicates": z.String().Trim().Max(5).Optional(),
})

// MemberRole is the input of the change-role form.
type MemberRole struct {
	Role string `json:"role" form:"role"`
}

// MemberRoleSchema validates MemberRole.
var MemberRoleSchema = z.Struct[MemberRole](z.Shape{
	"role": z.String().Trim().Min(1).Max(20),
})

// Transfer is the input of the ownership transfer form.
type Transfer struct {
	UserID string `json:"userId" form:"userId"`
}

// TransferSchema validates Transfer.
var TransferSchema = z.Struct[Transfer](z.Shape{
	"userId": z.String().Trim().Min(1).Max(20),
})

// AIKey is the input of the AI key form. The key field is named apiSecret so
// the framework never flashes it back as old input after a validation error
// (its secret-field rule matches "secret").
type AIKey struct {
	Provider  string `json:"provider"  form:"provider"`
	APISecret string `json:"apiSecret" form:"apiSecret"`
	Label     string `json:"label"     form:"label"`
	BaseURL   string `json:"baseUrl"   form:"baseUrl"`
	Model     string `json:"model"     form:"model"`
}

// AIKeySchema validates AIKey.
var AIKeySchema = z.Struct[AIKey](z.Shape{
	"provider":  z.String().Trim().Min(1).Max(30),
	"apiSecret": z.String().Trim().Min(1).Max(512),
	"label":     z.String().Trim().Max(80).Optional(),
	"baseUrl":   z.String().Trim().Max(500).Optional(),
	"model":     z.String().Trim().Max(100).Optional(),
})

// AISettings is the input of the AI switches form.
type AISettings struct {
	Enabled    bool   `json:"enabled"    form:"enabled"`
	Categorize bool   `json:"categorize" form:"categorize"`
	Assistant  bool   `json:"assistant"  form:"assistant"`
	Limit      string `json:"limit"      form:"limit"`
	Consent    bool   `json:"consent"    form:"consent"`
	// AutoApply is the opt-in to apply suggestions of at least 90 % confidence.
	AutoApply bool `json:"autoApply" form:"autoApply"`
}

// AISettingsSchema validates AISettings.
var AISettingsSchema = z.Struct[AISettings](z.Shape{
	"enabled":    z.Bool().Optional(),
	"categorize": z.Bool().Optional(),
	"assistant":  z.Bool().Optional(),
	"limit":      z.String().Trim().Min(1).Max(9),
	"consent":    z.Bool().Optional(),
	"autoApply":  z.Bool().Optional(),
})

// AccountTransfer is the input of the transfer form: money moves from one
// account to another of the same workspace.
type AccountTransfer struct {
	FromAccountID string `json:"fromAccountId" form:"fromAccountId"`
	ToAccountID   string `json:"toAccountId"   form:"toAccountId"`
	Amount        string `json:"amount"        form:"amount"`
	Description   string `json:"description"   form:"description"`
	Date          string `json:"date"          form:"date"`
}

// AccountTransferSchema validates AccountTransfer.
var AccountTransferSchema = z.Struct[AccountTransfer](z.Shape{
	"fromAccountId": z.String().Trim().Min(1).Max(20),
	"toAccountId":   z.String().Trim().Min(1).Max(20),
	"amount":        z.String().Trim().Min(1).Max(30),
	"description":   z.String().Trim().Max(200).Optional(),
	"date":          z.String().Trim().Min(10).Max(10),
})

// Card is the input of the credit card form. Days arrive as text and the
// finance service checks them (1 to 31); only the last four digits of the
// card are ever sent.
type Card struct {
	Name             string `json:"name"             form:"name"`
	Limit            string `json:"limit"            form:"limit"`
	ClosingDay       string `json:"closingDay"       form:"closingDay"`
	DueDay           string `json:"dueDay"           form:"dueDay"`
	PaymentAccountID string `json:"paymentAccountId" form:"paymentAccountId"`
	Brand            string `json:"brand"            form:"brand"`
	Last4            string `json:"last4"            form:"last4"`
}

// CardSchema validates Card.
var CardSchema = z.Struct[Card](z.Shape{
	"name":             z.String().Trim().Min(1).Max(80),
	"limit":            z.String().Trim().Min(1).Max(30),
	"closingDay":       z.String().Trim().Min(1).Max(2),
	"dueDay":           z.String().Trim().Min(1).Max(2),
	"paymentAccountId": z.String().Trim().Max(20).Optional(),
	"brand":            z.String().Trim().Max(20).Optional(),
	"last4":            z.String().Trim().Max(16).Optional(),
})

// StatementPayment is the input of the pay statement form. An empty amount
// pays what is left; an empty date means today.
type StatementPayment struct {
	FromAccountID string `json:"fromAccountId" form:"fromAccountId"`
	Amount        string `json:"amount"        form:"amount"`
	Date          string `json:"date"          form:"date"`
}

// StatementPaymentSchema validates StatementPayment.
var StatementPaymentSchema = z.Struct[StatementPayment](z.Shape{
	"fromAccountId": z.String().Trim().Min(1).Max(20),
	"amount":        z.String().Trim().Max(30).Optional(),
	"date":          z.String().Trim().Max(10).Optional(),
})

// Token is the input of the new API token form.
type Token struct {
	Name   string   `json:"name"   form:"name"`
	Scopes []string `json:"scopes" form:"scopes"`
	Days   string   `json:"days"   form:"days"`
}

// TokenSchema validates Token; the scopes and the expiry are checked by the
// token service, which owns the list.
var TokenSchema = z.Struct[Token](z.Shape{
	"name":   z.String().Trim().Min(1).Max(80),
	"scopes": z.Slice(z.String().Trim().Max(40)).Min(1).Max(40),
	"days":   z.String().Trim().Min(1).Max(4),
})

// Recurrence is the input of the recurring rule form. Interval and MaxCount
// arrive as text like the other numbers; an empty MaxCount means no limit.
type Recurrence struct {
	AccountID   string `json:"accountId"   form:"accountId"`
	CategoryID  string `json:"categoryId"  form:"categoryId"`
	Kind        string `json:"kind"        form:"kind"`
	Amount      string `json:"amount"      form:"amount"`
	Description string `json:"description" form:"description"`
	Frequency   string `json:"frequency"   form:"frequency"`
	Interval    string `json:"interval"    form:"interval"`
	StartDate   string `json:"startDate"   form:"startDate"`
	EndDate     string `json:"endDate"     form:"endDate"`
	MaxCount    string `json:"maxCount"    form:"maxCount"`
	Active      bool   `json:"active"      form:"active"`
	Backfill    bool   `json:"backfill"    form:"backfill"`
}

// RecurrenceSchema validates Recurrence.
var RecurrenceSchema = z.Struct[Recurrence](z.Shape{
	"accountId":   z.String().Trim().Min(1).Max(20),
	"categoryId":  z.String().Trim().Max(20).Optional(),
	"kind":        z.String().Trim().Min(1).Max(20),
	"amount":      z.String().Trim().Min(1).Max(30),
	"description": z.String().Trim().Max(200).Optional(),
	"frequency":   z.String().Trim().Min(1).Max(20),
	"interval":    z.String().Trim().Min(1).Max(6),
	"startDate":   z.String().Trim().Min(10).Max(10),
	"endDate":     z.String().Trim().Max(10).Optional(),
	"maxCount":    z.String().Trim().Max(6).Optional(),
	"active":      z.Bool().Optional(),
	"backfill":    z.Bool().Optional(),
})

// Installment is the input of the installment purchase form.
type Installment struct {
	AccountID   string   `json:"accountId"   form:"accountId"`
	CategoryID  string   `json:"categoryId"  form:"categoryId"`
	Total       string   `json:"total"       form:"total"`
	Parts       string   `json:"parts"       form:"parts"`
	FirstDate   string   `json:"firstDate"   form:"firstDate"`
	Description string   `json:"description" form:"description"`
	Tags        []string `json:"tags"        form:"tags"`
}

// InstallmentSchema validates Installment.
var InstallmentSchema = z.Struct[Installment](z.Shape{
	"accountId":   z.String().Trim().Min(1).Max(20),
	"categoryId":  z.String().Trim().Max(20).Optional(),
	"total":       z.String().Trim().Min(1).Max(30),
	"parts":       z.String().Trim().Min(1).Max(3),
	"firstDate":   z.String().Trim().Min(10).Max(10),
	"description": z.String().Trim().Max(200).Optional(),
	"tags":        z.Slice(z.String().Trim().Max(120)).Max(40).Optional(),
})

// TelegramAlerts is the input of the switch that sends alerts to Telegram.
type TelegramAlerts struct {
	Enabled string `json:"enabled" form:"enabled"`
}

// TelegramAlertsSchema validates TelegramAlerts: "true" or "false".
var TelegramAlertsSchema = z.Struct[TelegramAlerts](z.Shape{
	"enabled": z.String().Trim().Min(4).Max(5),
})

// AcceptAll is the input of "accept all above a confidence": min is a whole percent.
type AcceptAll struct {
	Min string `json:"min" form:"min"`
}

// AcceptAllSchema validates AcceptAll.
var AcceptAllSchema = z.Struct[AcceptAll](z.Shape{
	"min": z.String().Trim().Min(1).Max(3),
})

// EntryDraft is the input of the sentence to draft.
type EntryDraft struct {
	Text string `json:"text" form:"text"`
}

// EntryDraftSchema validates EntryDraft; the service enforces the exact length.
var EntryDraftSchema = z.Struct[EntryDraft](z.Shape{
	"text": z.String().Trim().Min(1).Max(1000),
})

// AssistantAsk is the input of a question to the assistant. ConversationID is
// empty to start a new conversation.
type AssistantAsk struct {
	Question       string `json:"question"       form:"question"`
	ConversationID string `json:"conversationId" form:"conversationId"`
}

// AssistantAskSchema validates AssistantAsk; the service enforces the exact length.
var AssistantAskSchema = z.Struct[AssistantAsk](z.Shape{
	"question":       z.String().Trim().Min(1).Max(2000),
	"conversationId": z.String().Trim().Max(20).Optional(),
})
