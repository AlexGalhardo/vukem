// Package config holds the application's own settings, read from the
// environment (.env).
package config

import (
	"errors"
	"regexp"
	"slices"
	"strings"

	vconfig "github.com/AlexGalhardo/vukem/config"
)

// Plan is a subscription plan sold with Stripe Checkout.
type Plan struct {
	// Name is the plan's key in URLs and in OnPlan ("pro").
	Name string `json:"name"`
	// Label is shown on the billing page.
	Label string `json:"label"`
	// Price is the Stripe price id (price_...), from STRIPE_PRICE_<NAME>.
	Price string `json:"-"`
}

// plans lists the plans on sale, in display order (vukem install:billing
// -plans). Add yours here and set STRIPE_PRICE_<NAME> to a recurring price
// id from the Stripe Dashboard.
func plans() []Plan {
	return []Plan{
		{Name: "pro", Label: "Pro"},
	}
}

var currencyRe = regexp.MustCompile(`^[a-z]{3}$`)

// Billing configures Stripe (vukem install:billing).
type Billing struct {
	// Key is the Stripe API key (STRIPE_KEY). Use a restricted key (rk_...)
	// with write access to Customers, Checkout Sessions and Customer portal
	// and read access to Subscriptions, nothing else.
	Key vconfig.Secret
	// WebhookSecret verifies webhooks (STRIPE_WEBHOOK_SECRET, whsec_...).
	// `stripe listen --forward-to localhost:3000/stripe/webhook` prints one
	// for development.
	WebhookSecret vconfig.Secret
	// Plans are the plans on sale.
	Plans []Plan
	// Currencies are the ISO 4217 currencies a checkout may ask for
	// (STRIPE_CURRENCIES, e.g. "brl,usd,eur"). Empty: every checkout uses
	// the price's default currency. One Stripe price per plan serves them
	// all when it lists the other currencies in currency_options.
	Currencies []string
	// Pix is the one-off PIX payment (AbacatePay), optional.
	Pix Pix
}

// LoadBilling reads the billing settings from src (app.Source).
func LoadBilling(src vconfig.Lookuper) Billing {
	get := func(key string) string {
		v, _ := src.Lookup(key)
		return strings.TrimSpace(v)
	}

	b := Billing{
		Key:           vconfig.NewSecret(get("STRIPE_KEY")),
		WebhookSecret: vconfig.NewSecret(get("STRIPE_WEBHOOK_SECRET")),
		Pix:           loadPix(get),
	}

	for _, p := range plans() {
		p.Price = get("STRIPE_PRICE_" + strings.ToUpper(p.Name))
		b.Plans = append(b.Plans, p)
	}

	for c := range strings.SplitSeq(get("STRIPE_CURRENCIES"), ",") {
		if c = strings.ToLower(strings.TrimSpace(c)); c != "" {
			b.Currencies = append(b.Currencies, c)
		}
	}

	return b
}

// Validate reports the missing settings; production refuses to boot
// without them.
func (b Billing) Validate() error {
	var errs []error

	if b.Key.IsZero() {
		errs = append(errs, errors.New("STRIPE_KEY is not set"))
	}

	if b.WebhookSecret.IsZero() {
		errs = append(errs, errors.New("STRIPE_WEBHOOK_SECRET is not set"))
	}

	for _, p := range b.Plans {
		if p.Price == "" {
			errs = append(errs, errors.New("STRIPE_PRICE_"+strings.ToUpper(p.Name)+" is not set"))
		}
	}

	for _, c := range b.Currencies {
		if !currencyRe.MatchString(c) {
			errs = append(errs, errors.New("STRIPE_CURRENCIES: "+c+" is not a three-letter currency code"))
		}
	}

	if b.Pix.Enabled() {
		if err := b.Pix.validate(); err != nil {
			errs = append(errs, err)
		}
	}

	return errors.Join(errs...)
}

// Plan returns the plan named name.
func (b Billing) Plan(name string) (Plan, bool) {
	for _, p := range b.Plans {
		if p.Name == name {
			return p, true
		}
	}

	return Plan{}, false
}

// Accepts reports whether a checkout may ask for currency (lower case).
func (b Billing) Accepts(currency string) bool { return slices.Contains(b.Currencies, currency) }

// PlanForPrice returns the plan that sells price.
func (b Billing) PlanForPrice(price string) (Plan, bool) {
	for _, p := range b.Plans {
		if p.Price != "" && p.Price == price {
			return p, true
		}
	}

	return Plan{}, false
}
